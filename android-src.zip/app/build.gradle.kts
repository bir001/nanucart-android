plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "app.nanucart.shop"
    compileSdk = 34
    defaultConfig {
        applicationId = "app.nanucart.shop"
        minSdk = 26
        targetSdk = 34
        versionCode = (project.findProperty("verCode") as String?)?.toIntOrNull() ?: 1
        versionName = "1." + (project.findProperty("verCode") ?: "0")
        buildConfigField("String", "SITE_URL", "\"" + (project.findProperty("siteUrl") ?: "https://bir001.github.io/Nanu-Cart/") + "\"")
    }
    buildFeatures { buildConfig = true }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
    signingConfigs {
        create("nanucart") {
            storeFile = file("nanucart.p12")
            storePassword = "nanucart123"
            keyAlias = "nanucart"
            keyPassword = "nanucart123"
            storeType = "pkcs12"
        }
    }
    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("nanucart")
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
