package app.nanucart.shop

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null

    private val offlineHtml = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>" +
        "<body style='margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;" +
        "background:linear-gradient(160deg,#04103F,#0B3BD6);font-family:sans-serif;color:#fff;text-align:center'>" +
        "<div style='padding:28px'><div style='font-size:54px'>&#128246;</div>" +
        "<h2 style='margin:12px 0 6px'>No internet connection</h2>" +
        "<p style='margin:0 0 22px;opacity:.8'>Please check your connection and try again.</p>" +
        "<button onclick='NanuNative.retry()' style='background:#FFC21A;color:#061552;border:0;border-radius:999px;" +
        "padding:14px 34px;font-size:16px;font-weight:700'>Try again</button></div></body></html>"

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#EEF3FF")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        web = WebView(this)
        setContentView(web)
        web.setBackgroundColor(Color.parseColor("#061552"))
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.allowFileAccess = false
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.userAgentString = s.userAgentString + " NanuCartApp/" + BuildConfig.VERSION_NAME
        web.addJavascriptInterface(Bridge(), "NanuNative")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                val scheme = u.scheme ?: ""
                if (scheme == "http" || scheme == "https") {
                    val host = Uri.parse(BuildConfig.SITE_URL).host
                    if (u.host == host) return false
                }
                try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (e: Exception) { }
                return true
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) {
                    view.loadDataWithBaseURL(null, offlineHtml, "text/html", "utf-8", null)
                }
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try {
                    startActivityForResult(p.createIntent(), 11)
                    true
                } catch (e: Exception) {
                    fileCb = null
                    false
                }
            }

            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread { request.deny() }
            }
        }
        web.loadUrl(BuildConfig.SITE_URL)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 11) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCb = null
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val js = "(function(){try{return (window.nativeBack&&nativeBack())?1:0}catch(e){return 0}})()"
        web.evaluateJavascript(js) { r ->
            if (r != "1") {
                if (web.canGoBack()) web.goBack() else finish()
            }
        }
    }

    override fun onPause() {
        super.onPause()
        web.onPause()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
    }

    inner class Bridge {
        @JavascriptInterface
        fun isNative(): Boolean = true

        @JavascriptInterface
        fun retry() {
            runOnUiThread { web.loadUrl(BuildConfig.SITE_URL) }
        }

        @JavascriptInterface
        fun saveFile(name: String, mime: String, b64: String) {
            thread {
                try {
                    val v = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, name)
                        put(MediaStore.Downloads.MIME_TYPE, mime)
                    }
                    val u = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
                        ?: throw Exception("Cannot create file")
                    contentResolver.openOutputStream(u)!!.use { it.write(Base64.decode(b64, Base64.DEFAULT)) }
                    runOnUiThread {
                        Toast.makeText(this@MainActivity, "Saved to Downloads: " + name, Toast.LENGTH_LONG).show()
                        try {
                            val i = Intent(Intent.ACTION_VIEW)
                            i.setDataAndType(u, mime)
                            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                            startActivity(i)
                        } catch (e: Exception) { }
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        Toast.makeText(this@MainActivity, "Could not save file", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }
}
